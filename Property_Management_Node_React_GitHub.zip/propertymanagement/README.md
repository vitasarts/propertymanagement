# Barbour Property Management

A standalone Airbnb-inspired rental website and private property-management dashboard for [vitasarts/propertymanagement](https://github.com/vitasarts/propertymanagement).

## Included

- Public rental listings with property photos, amenities, pricing, and rental details.
- Two editable starting drafts: an apartment and a condo.
- Add more properties without a fixed property limit.
- Monthly or nightly rental-rate display.
- Inquiries and tour requests stored in the manager dashboard.
- Rental applications with required identification: front and back of a driver's license/state ID, or the passport photo/details page.
- Application decisions: Pending review, Approved, Declined, More information needed.
- Only approved applicants can be added as tenants for the corresponding property.
- Private manager login, tenant records, rent ledger, maintenance records, documents, and CSV exports.
- Local SQLite storage and private uploaded files outside the public folder.

The rent ledger records payments received elsewhere; it does not charge cards or collect rent. Application approvals are manual decisions, not automated identity or background checks. Contact applicants directly with decisions; the app does not send email notifications. Nightly pricing does not include a booking calendar or reservation engine.

## Requirements

- Node.js **22.13 or newer**, preferably Node 24.
- npm.
- A Node.js hosting service with a persistent, writable directory or volume.
- HTTPS when accepting real applications.

**This is a server application, not a static HTML upload. GitHub Pages, ordinary static hosting, and a PHP-only account cannot run the dashboard, database, or private uploads.** Hosts with temporary/ephemeral disks need an attached persistent volume. Use one application instance for this SQLite/local-file edition.

## Quick start on your computer

1. Extract the ZIP and open a terminal in the folder containing `package.json`.
2. Install packages:

   ```bash
   npm install
   ```

3. Create manager-login configuration:

   ```bash
   npm run setup
   ```

   Enter your manager email. The command creates `.env.local`, hashes a randomly generated password, and displays that password once. Save it in your password manager. The ZIP contains no manager password or private key.

4. Start local testing:

   ```bash
   npm run dev
   ```

5. Open **http://localhost:3000** for the rental website, or **http://localhost:3000/dashboard** for manager login.

The two draft properties are created when you first open the authenticated dashboard. No renter/tenant data or uploaded IDs from the hosted ChatGPT version are included.

## Prepare your properties

1. Sign in to **Manager dashboard**.
2. Open **Settings** and enter your business name, email, phone, and description.
3. Open **Properties** and edit the apartment and condo drafts.
4. Enter the real name, address, rent, bedrooms, bathrooms, description, amenities, and policies.
5. Save the listing. Reopen it to upload real property photos.
6. Set its status to **Available** when ready for renters to see it.
7. Use **Add property** for additional listings. Draft, Occupied, and Unavailable listings are hidden from the public rental website.

## Application and approval workflow

1. The renter selects an available listing and clicks **Apply to rent**.
2. The renter provides their name, email, optional phone, ID type, required document images/pages, and consent.
3. The application is saved as **Pending review**; submission does not approve the renter.
4. The manager opens **Applications**, reviews the private documents, and records the decision.
5. After approval, open **Tenants → Add tenant** and select the approved application for that property.
6. Contact the applicant directly regarding the decision, lease, or next steps.

Documents are not stored in `public/`. Identity documents require manager login to download. Public photo URLs only serve photos attached to currently Available properties. Files are limited to 10 MB each.

## Build and test

```bash
npm test
npm run typecheck
npm run build
npm run test:integration
npm start
```

`npm run test:integration` starts a temporary test server, uses fake ID documents, checks approval/access rules, and removes its temporary database afterward.

`npm start` serves the production build, normally on port 3000. To use another port:

```bash
npm start -- -p 8080
```

If your hosting panel asks for a Node startup file, use `server.mjs` after building. It respects the host's `PORT` environment variable. It must be a Node 22.13+ application, not PHP hosting.

## Test on your own website / production hosting

1. Upload or clone the source onto a Node-compatible host.
2. Run `npm install` and `npm run build`.
3. Run `npm run setup` on the host, or configure the corresponding environment variables using the hosting control panel. Keep secrets out of GitHub.
4. Configure:

   | Variable | Value |
   | --- | --- |
   | `MANAGER_EMAIL` | Your manager login email |
   | `MANAGER_PASSWORD_HASH` | The scrypt hash generated by setup |
   | `SESSION_SECRET` | The random secret generated by setup |
   | `DATA_DIR` | An absolute persistent directory, such as `/var/lib/propertymanagement` |
   | `APP_URL` | Your full public origin, such as `https://rentals.yourdomain.com`, with no trailing slash |
   | `COOKIE_SECURE` | `true` on an HTTPS site |
   | `PORT` | The port assigned by your hosting service, if applicable |

5. Start the app with `npm start` or the hosting service's Node process manager.
6. Point your domain/subdomain at the application and configure HTTPS. A reverse proxy must pass requests to the Node app without exposing `data/`.
7. Verify the public listings, manager login, both ID options, approval decisions, and file-download access using test files before collecting real renter documents.

The app works best at a domain or subdomain root, such as `https://rentals.example.com`. Installing inside a path such as `/propertymanagement/` requires adapting the links and API URLs; it is not configured in this package.

## Add these files to GitHub

Your repository: **https://github.com/vitasarts/propertymanagement**

The provided ZIP contains source files. Extract it first. Upload the contents of the `propertymanagement` folder into the repository root so that `package.json`, `app/`, and `lib/` are at the top level. Preserve the `.gitignore` and `.env.example` files.

If using Git locally:

```bash
git clone https://github.com/vitasarts/propertymanagement.git
cd propertymanagement
```

Copy the extracted source contents into that folder, then:

```bash
git add .
git commit -m "Add rental website and property management dashboard"
git push origin main
```

If the default branch has another name, use that branch instead of `main`.

Never commit `.env.local`, `data/`, uploaded IDs, database files, or `node_modules/`. The included `.gitignore` excludes these. This delivery does not change or push to your GitHub repository.

## Backup and maintenance

`DATA_DIR` contains:

- `propertymanagement.sqlite`: property and application records.
- `propertymanagement.sqlite-wal` / `-shm`: SQLite journal files while running.
- `uploads/`: private documents and listing photos.

To make a simple complete backup, stop the Node process and copy the entire `DATA_DIR`, then restart. Protect the backup with the same access controls as the live records. Restoring requires the database and its matching uploaded files together.

To rotate the login password, generate a new configuration with `npm run setup` in a temporary directory and replace `MANAGER_PASSWORD_HASH` on the host. Change `SESSION_SECRET` too to invalidate existing sessions. Do not overwrite the application's data directory.

The app does not include automated document-retention/deletion rules, email delivery, online payments, background checks, or multiple manager accounts. Uploaded IDs remain on your server until you remove them through a deliberate administrative process. Restrict access to the data directory and backups.

## Project layout

```text
app/                 Pages and server API routes
lib/                 SQLite storage, file storage, manager authentication
public/              Favicon and public assets
scripts/setup.mjs    Generates private login configuration
server.mjs           Optional Node startup file for hosting panels
tests/               Storage and login tests
.env.example         Configuration template without secrets
README.md            Setup, GitHub, and hosting instructions
```

This version replaces the original host-specific Cloudflare/ChatGPT storage and sign-in. It can run independently on a supported Node host without a ChatGPT login. The existing hosted Site has not been modified.
