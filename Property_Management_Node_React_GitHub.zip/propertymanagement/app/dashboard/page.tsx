import { requireManager } from '../../lib/auth';
import Dashboard from './workspace';
export const dynamic='force-dynamic';
export default async function Page(){await requireManager('/dashboard');return <Dashboard/>;}
