import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'Barbour Property Management',description:'Rental homes and a property management workspace.',icons:{icon:'/favicon.svg'}};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>;}
