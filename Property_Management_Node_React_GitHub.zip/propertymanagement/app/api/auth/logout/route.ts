import {cookies} from 'next/headers';
import {SESSION_COOKIE,cookieOptions} from '../../../../lib/session.mjs';
import {sameOrigin} from '../../../../lib/store';
export async function POST(req:Request){if(!sameOrigin(req))return new Response(null,{status:403});(await cookies()).set(SESSION_COOKIE,'',{...cookieOptions(),maxAge:0});return Response.json({ok:true});}
