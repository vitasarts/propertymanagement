import {cookies} from 'next/headers';
import {timingSafeEqual,createHash} from 'node:crypto';
import {SESSION_COOKIE,verifyPassword,createSession,cookieOptions} from '../../../../lib/session.mjs';
import {database,sameOrigin} from '../../../../lib/store';
export const runtime='nodejs';
export async function POST(req:Request){
 if(!sameOrigin(req))return Response.json({error:'Invalid request origin.'},{status:403});
 if(!process.env.MANAGER_EMAIL||!process.env.MANAGER_PASSWORD_HASH||!process.env.SESSION_SECRET)return Response.json({error:'Manager login is not configured. Run npm run setup.'},{status:503});
 try{const {email,password}=await req.json();if(typeof email!=='string'||typeof password!=='string'||email.length>300||password.length>512)return Response.json({error:'Enter your email and password.'},{status:400});
 const key='manager',db=database(),now=Date.now(),windowMs=15*60*1000;let entry=db.prepare('SELECT * FROM login_attempts WHERE key=?').bind(key).first();if(entry&&now-entry.started>=windowMs){db.prepare('DELETE FROM login_attempts WHERE key=?').bind(key).run();entry=null;}if(entry&&entry.attempts>=10)return Response.json({error:'Too many attempts. Please wait 15 minutes before trying again.'},{status:429});
 const sameEmail=timingSafeEqual(createHash('sha256').update(email.toLowerCase()).digest(),createHash('sha256').update(process.env.MANAGER_EMAIL.toLowerCase()).digest());const validPassword=verifyPassword(password,process.env.MANAGER_PASSWORD_HASH);
 if(!sameEmail||!validPassword){db.prepare('INSERT INTO login_attempts(key,attempts,started) VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET attempts=attempts+1').bind(key,now).run();return Response.json({error:'Email or password is incorrect.'},{status:401});}
 db.prepare('DELETE FROM login_attempts WHERE key=?').bind(key).run();(await cookies()).set(SESSION_COOKIE,createSession(process.env.MANAGER_EMAIL),cookieOptions());return Response.json({ok:true});
 }catch(e){console.error('Login failed');return Response.json({error:'Unable to sign in. Check the server configuration.'},{status:503});}
}
