import {createServer} from 'node:http';
import next from 'next';
const app=next({dev:false,hostname:'0.0.0.0',port:Number(process.env.PORT||3000)});
await app.prepare();const handler=app.getRequestHandler();
createServer((req,res)=>handler(req,res)).listen(Number(process.env.PORT||3000),'0.0.0.0',()=>console.log('Property management server is ready.'));
