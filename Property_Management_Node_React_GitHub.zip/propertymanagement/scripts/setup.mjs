import { existsSync,writeFileSync } from 'node:fs';
import {randomBytes} from 'node:crypto';
import {createInterface} from 'node:readline/promises';
import {hashPassword} from '../lib/session.mjs';
if(existsSync('.env.local')){console.error('.env.local already exists. It was preserved. To change your password, run setup in a temporary folder and copy only MANAGER_PASSWORD_HASH, or remove the existing configuration after backing it up.');process.exit(1);}
const rl=createInterface({input:process.stdin,output:process.stdout});let email=process.env.SETUP_EMAIL||'';
if(!email){email=(await rl.question('Manager email address: ')).trim();}rl.close();
if(!/^\S+@\S+\.\S+$/.test(email)){console.error('Enter a valid email address.');process.exit(1);}
const password=randomBytes(18).toString('base64url');
writeFileSync('.env.local',`MANAGER_EMAIL=${JSON.stringify(email)}\nMANAGER_PASSWORD_HASH=${hashPassword(password)}\nSESSION_SECRET=${randomBytes(48).toString('hex')}\nDATA_DIR=./data\nAPP_URL=http://localhost:3000\nCOOKIE_SECURE=false\n`,{mode:0o600});
console.log('\nConfiguration created. Save these details in your password manager.\nEmail: '+email+'\nGenerated password: '+password+'\n\nDo not commit .env.local to GitHub.');
