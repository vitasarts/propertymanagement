import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {randomBytes} from 'node:crypto';
import {hashPassword} from '../lib/session.mjs';
const data=mkdtempSync(join(tmpdir(),'pm-production-test-')),port=Number(process.env.TEST_PORT||3051),origin='http://127.0.0.1:'+port,password=randomBytes(18).toString('hex');
const proc=spawn(process.execPath,['server.mjs'],{env:{...process.env,PORT:String(port),MANAGER_EMAIL:'test@example.test',MANAGER_PASSWORD_HASH:hashPassword(password),SESSION_SECRET:randomBytes(48).toString('hex'),DATA_DIR:data,APP_URL:origin,COOKIE_SECURE:'false',NEXT_TELEMETRY_DISABLED:'1'},stdio:['ignore','pipe','pipe']});let logs='';proc.stdout.on('data',d=>logs+=d);proc.stderr.on('data',d=>logs+=d);
let cookie='';
async function call(path,options={},manager=false){const r=await fetch(origin+path,{...options,headers:{...(options.headers||{}),Origin:origin,...(manager?{Cookie:cookie}:{})}});const text=await r.text();let body;try{body=JSON.parse(text);}catch{body=text;}return {status:r.status,body,headers:r.headers};}
const json=(data)=>({method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
try{
 for(let i=0;i<100;i++){try{const r=await fetch(origin+'/login');if(r.ok)break;}catch{}if(i===99)throw Error('Server did not start: '+logs);await new Promise(r=>setTimeout(r,150));}
 assert.equal((await call('/api/manage')).status,403,'Anonymous dashboard access denied');
 const login=await call('/api/auth/login',json({email:'test@example.test',password}));assert.equal(login.status,200);cookie=login.headers.get('set-cookie').split(';')[0];
 const initial=await call('/api/manage',{},true);assert.equal(initial.status,200);assert.equal(initial.body.records.filter(r=>r.kind==='property').length,2);
 const property={name:'Integration test apartment',type:'Apartment',status:'Available',address:'Test address',rent:'1000',description:'Test only',photos:[]};
 const saved=await call('/api/manage',json({kind:'property',data:property}),true);assert.equal(saved.status,200);const id=saved.body.id;
 assert.equal((await call('/api/listings')).body.properties.length,1,'Only available listing visible');
 function application(type,includeBack){const form=new FormData();form.set('name','Test renter');form.set('email','renter@example.test');form.set('property',id);form.set('idType',type);form.set('consent','true');form.set('front',new Blob(['%PDF-1.4\nTest fixture\n%%EOF'],{type:'application/pdf'}),'test-front.pdf');if(includeBack)form.set('back',new Blob(['%PDF-1.4\nTest fixture\n%%EOF'],{type:'application/pdf'}),'test-back.pdf');return {method:'POST',body:form};}
 assert.equal((await call('/api/applications',application('State ID',false))).status,400,'State ID requires both sides');
 assert.equal((await call('/api/applications',application('Passport',false))).status,200,'Passport accepts photo page');
 assert.equal((await call('/api/applications',application('Driver’s license',true))).status,200,'License accepts both sides');
 const records=(await call('/api/manage',{},true)).body.records,app=records.find(r=>r.kind==='application'&&r.idType==='Passport');assert.equal(app.status,'Pending review');
 assert.equal((await call('/api/files/'+app.front)).status,403,'Anonymous ID access denied');assert.equal((await call('/api/files/'+app.front,{},true)).status,200,'Manager can retrieve ID');
 const tenant={name:app.name,property:id,application:app.id};assert.equal((await call('/api/manage',json({kind:'tenant',data:tenant}),true)).status,400,'Pending renter cannot become tenant');
 assert.equal((await call('/api/manage',json({kind:'application',id:app.id,data:{...app,status:'Approved'}}),true)).status,200);
 assert.equal((await call('/api/manage',json({kind:'tenant',data:tenant}),true)).status,200,'Approved renter can become tenant');
 assert.equal((await call('/api/manage',{},true)).body.records.filter(r=>r.kind==='property').length,3,'Additional property persists');
 console.log('Production verification passed: login, three properties, draft visibility, ID requirements, private downloads, and approval enforcement.');
}finally{proc.kill('SIGTERM');await new Promise(r=>{if(proc.exitCode!==null)r();else proc.once('exit',r)});rmSync(data,{recursive:true,force:true});}
