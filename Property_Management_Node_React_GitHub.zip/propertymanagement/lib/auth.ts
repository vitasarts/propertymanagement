import { cookies } from 'next/headers';
import {redirect} from 'next/navigation';
import {SESSION_COOKIE,verifySession} from './session.mjs';
export async function getManager(){const token=(await cookies()).get(SESSION_COOKIE)?.value;return token?verifySession(token):null;}
export async function requireManager(returnTo='/dashboard'){const user=await getManager();if(user)return user;redirect('/login?next='+encodeURIComponent(returnTo));}
